# Testing

## Standard Gates

```bash
make docs-test
go test ./...
go vet ./...
make release-test
make release-workflow-test
```

对并发、state、runtime 和 provider 公共路径运行对应 `go test -race`。

## Example And Contract Tests

构建示例必须通过 validate/plan。Shell 脚本运行 `bash -n`，Go 源码运行 `gofmt`。Release tests 验证归档、checksum、metadata、OCI identity 和 GitHub workflow contract。

`make docs-test` 固定正式文档集合，限制 README 重新膨胀，并检查相对链接和已退役路径。新增正式主题时必须有明确单一事实归属，同时更新该门禁。

架构审查记录位于 `docs/design/`，不属于正式手册集合；它们记录待修复问题、验证证据和当前实施边界。

## Privileged Tests

```bash
make test-privileged-container
```

该门禁验证真实 netns、bridge、veth、TAP、Docker、nftables policy、readback、checkpoint recovery 和 residue cleanup，需要受控 Linux 宿主机权限。

## Heterogeneous Acceptance

```bash
make test-heterogeneous-matrix
make test-heterogeneous-reset
```

Matrix 验证 Docker、Firecracker 和 libvirt 节点共用 IPv4 网络的六个有向通信路径、重复 plan 与 destroy。Reset 验证三次完整 reset、逐 provider targeted reset、external identity replacement、稳定地址/artifact identity，以及最终零归属残留。

这些测试需要 KVM、Firecracker、libvirt、Docker 和准备好的 artifact，不能在不可信 pull request runner 上执行。

## Evidence Standard

验收报告至少记录 commit、宿主机能力、artifact digest、运行命令、通过断言和 residue audit。结果必须来自同一 release commit，不能以服务端口开放代替完整生命周期验证。

## Requirement reconciliation campaign

`scripts/acceptance/campaign.json` maps every original P5/P6/P8/P9 checklist item
and stage acceptance criterion to exact test gates and explicit remaining work.
Run `/usr/bin/python3 scripts/acceptance/campaign.py check` to detect missing
requirements, changed wording and nonexistent tests. `run --gate <id> --output
<new-directory>` writes raw Go JSON events, stderr, exit codes, source/embedded
binary digest and external artifact fingerprints. Database gate variables are
listed explicitly; API uses `SYSBOX_TEST_DATABASE_URL`, persistence uses
`SYSBOX_TEST_POSTGRES_DSN`. Configure both for a shared isolated test server.

`reconcile --evidence <directory>` validates those artifacts against current
source and returns2 while any requirement is open/unverified. A test skip,
unmatched test/package, nonzero exit, unfinished event stream, changed source or
changed helper/kernel/rootfs is never a pass. Passing a contract gate does not
close a row with declared remaining provider/fault coverage. Keep the output
outside the source tree so evidence files cannot recursively change the source
identity. This tool records acceptance; it does not merge, publish, migrate old
ledgers or authorize operations against historical environments.
